package com.cg.hms.exception;

public class HotelBookingException extends Exception 
{
	String msg;
	public HotelBookingException(String msg)
	{
		this.msg=msg;
	}
	@Override
	public String toString() {
		return "HotelBookingException [error=" + msg + "]";
	}
	
	
}
