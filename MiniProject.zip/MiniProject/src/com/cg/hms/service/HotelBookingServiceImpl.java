package com.cg.hms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

import com.cg.hms.dao.HotelBookingDaoImpl;
import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;

public class HotelBookingServiceImpl implements HotelBookingService 
{
	HotelBookingDaoImpl hbdao=null;
	public HotelBookingServiceImpl() 
	{
		 hbdao=new HotelBookingDaoImpl(); 
	}

	@Override
	public int register(User user) throws HotelBookingException 
	{
		return hbdao.register(user);
	}

	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
			return hbdao.login(role,userId, password);
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException 
	{
		return hbdao.addHotel(hotel);
	}

	@Override
	public int modifyHotel(int hotelId,String description)throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.modifyHotel(hotelId,description);
	}

	@Override
	public int deleteHotel(int hotel_id) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.deleteHotel(hotel_id);
	}

	@Override
	public int addRoom(RoomDetails room) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.addRoom(room);
	}

	
/*	public int modifyRoom(RoomDetails room) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.modifyRoom(room);
	}*/

	@Override
	public int deleteRoom(String hotel_id,String room_id) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.deleteRoom(hotel_id,room_id);
	}

	@Override
	public String bookRoom(BookingDetails bookingDetails)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.bookRoom(bookingDetails);
	}

	@Override
	public BookingDetails viewBookingStatus(int bookingId)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.viewBookingStatus(bookingId);
	}

	@Override
	public ArrayList<RoomDetails> searchRoom(int hotelId)
			throws HotelBookingException
	{
		// TODO Auto-generated method stub
		return hbdao.searchRoom(hotelId);
	}

	@Override
	public ArrayList<Hotel> displayHotels() throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.displayHotels();
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByHotel(int hotelId)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.viewBookingByHotel(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> viewGuestListOfHotel(int hotelId)
			throws HotelBookingException
	{
		// TODO Auto-generated method stub
		return hbdao.viewGuestListOfHotel(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByDate(Date date)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.viewBookingByDate(date);
	}

	@Override
	public boolean validateName(String name) throws HotelBookingException
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, name)&&name.length()<=30)
			return true;
			
		else
			throw new HotelBookingException("Inavlid Name.It Should start with capital "
					                           + "and only characters allowed");
	}

	@Override
	public boolean validateEmail(String email) throws HotelBookingException
	{
		
		String mailPattern="[a-z]{1,10}+[0-9]{0,5}+@[a-z]{1,10}+.com";
		if(Pattern.matches(mailPattern, email))
			return true;
			
		else
			throw new HotelBookingException("Inavlid MailId");
	}

	@Override
	public boolean validateContact(String contact) throws HotelBookingException
	{
		
		String phonePattern="[0-9]{10}";
		if(Pattern.matches(phonePattern, contact))
			return true;
			
		else
			throw new HotelBookingException("Inavlid phoneno");
	}

	@Override
	public boolean validatePassword(String password) throws HotelBookingException
	{
		String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
		if(password.matches(pattern))
			return true;
		else
			throw new HotelBookingException("Invalid password");
		
	}
}
